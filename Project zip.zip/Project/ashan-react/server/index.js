import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import OpenAI from 'openai';

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '20kb' }));
const port = Number(process.env.PORT || 3001);

app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) }));
app.post('/api/chat', async (req, res) => {
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';
  const language = typeof req.body?.language === 'string' ? req.body.language : 'English';
  const context = typeof req.body?.context === 'string' ? req.body.context.slice(0, 1500) : '';
  if (!message) return res.status(400).json({ error: 'Please enter a question.' });
  if (message.length > 4000) return res.status(413).json({ error: 'Please keep your question under 4,000 characters.' });
  if (!process.env.OPENAI_API_KEY) return res.status(503).json({ error: 'AI is not configured. Add OPENAI_API_KEY to your server .env file.' });
  try {
    const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || 'gpt-4.1-mini',
      instructions: `You are Guru, a warm, patient learning assistant for the Ashan education platform. Respond in ${language}. Explain at the learner's level, break concepts into clear steps, use simple examples, and ask a short follow-up question when useful. Help learners understand rather than merely copy answers. Do not claim certainty about changing exam eligibility or career rules; encourage official verification. Context: ${context}`,
      input: message,
      max_output_tokens: 700
    });
    res.json({ reply: response.output_text || 'Let’s try explaining that in a different way. What part feels confusing?' });
  } catch (error) {
    console.error('AI request failed:', error?.message || error);
    res.status(502).json({ error: 'Guru could not answer right now. Please try again in a moment.' });
  }
});
app.listen(port, () => console.log(`Ashan AI server listening on http://localhost:${port}`));
